function MouseEventsExample() {
    const handleClick = (event) => {
      console.log("Clicked element:", event.target);
    };
  
    const handleDoubleClick = (event) => {
      console.log("Double clicked!");
    };
  
    const handleMouseEnter = (event) => {
      console.log("Mouse entered:", event.target);
    };
  
    const handleMouseLeave = (event) => {
      console.log("Mouse left:", event.target);
    };
  
    const handleMouseMove = (event) => {
      console.log("Mouse moved:", event.clientX, event.clientY);
    };
  
    return (
      <div>
        <button onClick={handleClick}>Click Me</button>
        <div onDoubleClick={handleDoubleClick}>Double Click Me</div>
        <div onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Hover Over Me
        </div>
        <div onMouseMove={handleMouseMove}>Move your mouse here</div>
      </div>
    );
  }


//   function MouseEventsExample({ items }) {
//     const handleClick = (item) => {
//       console.log("Item clicked:", item);
//     };
  
//     return (
//       <div>
//         {items.map((item, index) => (
//           <button key={index} onClick={() => handleClick(item)}>
//             Click on {item}
//           </button>
//         ))}
//       </div>
//     );
//   }
  