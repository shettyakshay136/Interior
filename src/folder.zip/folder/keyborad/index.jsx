function KeyboardEventsExample() {
    const handleKeyDown = (event) => {
      console.log("Key down:", event.key);
    };
  
    const handleKeyUp = (event) => {
      console.log("Key up:", event.key);
    };
  
    return (
      <input 
        onKeyDown={handleKeyDown} 
        onKeyUp={handleKeyUp} 
        placeholder="Type something..."
      />
    );
  }



//   function KeyboardEventsExample({ placeholderText }) {
//     const handleKeyDown = (event, item) => {
//       console.log(`Key down: ${event.key}, Context: ${item}`);
//     };
  
//     return (
//       <input
//         placeholder={placeholderText}
//         onKeyDown={(e) => handleKeyDown(e, "Input Field")}
//       />
//     );
//   }
  
  